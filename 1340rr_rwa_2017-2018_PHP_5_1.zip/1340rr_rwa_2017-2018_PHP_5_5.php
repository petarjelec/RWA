<html>
	<head>
		<title>JMBG</title>
	</head>
	<body>
		<form action="" method="get">
		Unesite JMBG:<input name="broj" type="number" >
		<input type="submit" value="Click here">
		</form>

	<?php		 
	if(isset($_GET["broj"])){
		$jmbg = $_GET["broj"];
		$jmbglength=strlen((string)$jmbg);
		if($jmbglength==13){
			$dani = substr($jmbg, 0,2);
			$mjesec = substr($jmbg, 2,2);
			$godina = substr($jmbg, 4,3);
			$mjesto = substr($jmbg, 7,2);
			$spol = substr($jmbg, 10,3);
		if($mjesec>0 && $mjesec<13 && $dani>0 && $dani<32)
		{
			echo "Dan rodenja: ", $dani, "<br>";
			echo "Mjesec rodenja: ", $mjesec, "<br>";
		}
		else{
			echo "Greska u jmgb! <br>";
		}
		echo "Godina rodenja: 1", $godina, "<br>";
		if($spol>499)
		{
			echo "Spol: Muški <br>";
		}
		else{
			echo "Spol: Ženski <br>";
		}
		if($mjesto==10)
		{
			echo "Grad: Banjaluka";
		}
		else if($mjesto==11)
		{
			echo "Grad: Bihac";
		}
		else if($mjesto==12)
		{
			echo "Grad: Doboj";
		}
		else if($mjesto==13)
		{
			echo "Grad: Gorazde";
		}
		else if($mjesto==14)
		{
			echo "Grad: Livno";
		}
		else if($mjesto==15)
		{
			echo "Grad: Mostar";
		}
		else if($mjesto==16)
		{
			echo "Grad: Prijedor";
		}
		else if ($mjesto==17)
		{
			echo"Grad: Sarajevo";
		}
		else if ($mjesto==18)
		{
			echo"Grad: Tuzla";
		}
		else if ($mjesto==19)
		{
			echo"Grad: Zenica";
		}
		}
		else{
			echo "Niste unjeli dovoljno brojeva!";
		}

	}
	?>

 


	</body>
</html>