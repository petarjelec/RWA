
<html>
	<head>
		<title>Aritmetička sredina</title>
	</head>
	<body>
		<form action="" method="get">
			Unesite prvi broj:<input name="broj1" type="number" >
			Unesite drugi broj:<input name="broj2" type="number" >
			<input type="submit" value="Izračunaj">
		</form>
		<?php
						if(isset($_GET["broj1"]) && isset($_GET["broj2"]))
						{
						
						$br1=$_GET["broj1"];
						$br2=$_GET["broj2"];
				
						$aritm=($br1+$br2)/2;
						echo "Aritmetička sredina je: ", $aritm;
						}
						
		?>	
			
	</body>
</html>