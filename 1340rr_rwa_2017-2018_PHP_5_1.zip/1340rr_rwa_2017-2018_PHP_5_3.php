<html>
	<head>
		<title>Faktorijel</title>
	</head>
	<body>
		<form action="" method="get">
			Unesite broj:<input name="broj" type="number" >
			<input type="submit" value="Izračunaj">
		</form>
		
			<?php
					if(isset($_GET["broj"])){
						$br=$_GET["broj"];
						$fakt = 1;
						for($j=1; $j<=$br;$j++)
						{
							$fakt = $fakt * $j;
							echo $j, "!=", $fakt, "<br>";
						}
					}
			?>	
	</body>
</html>